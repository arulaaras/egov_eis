  <footer class="section blue darken-2 white-text center" style="padding: 4px !important;">
      <p>Copyright &copy; TNeGA 2018</p>
    </footer>
  </body>
</html>