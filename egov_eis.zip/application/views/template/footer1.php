    <footer class="page-footer blue">
      <div class="container">
        <div class="row">
          <div class="col m8 l8 s12">
            <h5 class="white-text">About</h5>
            <p class="grey-text text-lighten-4">Tamil Nadu e-Governance Agency (TNeGA), as a State Nodal Agency has been formed to support and drive all e-Governance initiatives of the Government of Tamil Nadu.</p>
  
  
          </div>
          
          <div class="col m4 l4 s12 right">
            <h5 class="white-text">Connect</h5>
            <ul>
                <li><a class="white-text" href="#!">Government of Tamil Nadu</a></li>
                <li><a class="white-text" href="#!">Department of Information Technology</a></li>
                <li><a class="white-text" href="#!">National Informatics Centre</a></li>
                <li><a class="white-text" href="#!">ELCOT</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="footer-copyright">
        <div class="container center">
        Powered by <a class="white-text" href="https://www.tnega.tn.gov.in">TNeGA</a>
        </div>
      </div>
    </footer>
  </body>
</html>